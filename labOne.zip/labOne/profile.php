<?php
session_start();
include 'connect.php';

// Check if the user is logged in
if (!isset($_SESSION["user_id"])) {
    // Redirect to the login page if not logged in
    header("Location: login.php");
    exit();
}

// Fetch the logged-in user's ID from the session
$loggedInUserId = $_SESSION["user_id"];

// Fetch the user data from the database based on the logged-in user's ID
$sql = "SELECT * FROM nothing WHERE user_id = '$loggedInUserId'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    // User found in the database
    $user = $result->fetch_assoc();
}
else {
    // User not found or an error occurred
    $user = null;
}

// Check if the form is submitted for editing or saving
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["edit"])) {
    $editing = true;
} else {
    $editing = false;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["save"])) {
    // Retrieve the updated data from the form
    $name = $_POST["name"];
    $birth_date = $_POST["birth_date"]; 
    $age = $_POST["age"]; 
    $account_type = $_POST["accType"];
    $favorite_rock = $_POST["favRock"];

    // Update the user details in the database
    $sql = "UPDATE nothing SET name = '$name', birth_date = '$birth_date', age = '$age', accType = '$account_type', favRock = '$favorite_rock' WHERE user_id = '$loggedInUserId'";
    $result = $conn->query($sql);

    if ($result) {
        // Update the user information in the session
        $user["name"] = $name;
        $user["birth_date"] = $birth_date;
        $user["age"] = $age;
        $user["accType"] = $account_type;
        $user["favRock"] = $favorite_rock;

        // Recalculate the age based on the updated birth date
        $birth_date_obj = new DateTime($birth_date);
        $current_date = new DateTime();
        $age = $current_date->diff($birth_date_obj)->y;
      
        // Update the age in the user array and session
        $sql = "UPDATE nothing SET age ='$age' WHERE user_id = '$loggedInUserId'";
        $result = $conn->query($sql);

        $user["age"] = $age;
        $_SESSION["user"]["age"] = $age;

        $_SESSION["user"] = $user;
    } else {
        echo "Error updating user details: " . $conn->error;
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
    $id = $_SESSION['user_id']; // Get the user ID from the session

    // Use prepared statement to prevent SQL injection
    $sql = "DELETE FROM nothing WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $id);

        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            // Log out the user and destroy the session
            session_destroy();
            header('Location: login.php');
            exit; // Make sure to stop script execution after the redirection
        } else {
            echo "Delete failed: " . mysqli_error($conn);
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ROCKS rock</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" id="theme-style" href="dark.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dosis:wght@500&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <nav class="nav1">
            <a href="one.html" class="links">Rock Info</a>
            <a href="two.html" class="links">Rock List</a>
            <a href="three.html" class="links">Rock Table</a>
            <a href="profile.php" class="active links">Profile</a>
            <a href="logout.php" class="loGout">Logout</a>
        </nav>
    </header>
    <main>
        <button id="theme-toggle" onclick="toggleTheme()">Toggle Theme</button>
        <div class="profile-container">
            <?php if ($editing) : ?>
                <!-- Display the profile form for editing -->
                <form class="profile-form" action="" method="post">
                    <br>
                    <h1>Edit Profile</h1>
                    <div class = "profile_up">
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="name" value="<?php echo $user['name']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="birth_date">Date of Birth:</label>
                        <input type="date" id="birth_date" name="birth_date" value="<?php echo $user['birth_date']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="age">Age:</label>
                        <input type="text" id="age" name="age" readonly value="<?php echo $user['age']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="account_type">Account Type:</label>
                        <select name="accType" id="account_type" class="form__input">
                            <option value="">--Select an option--</option>
                            <option value="Veteran" <?php if ($user['accType'] === 'Veteran') echo 'selected'; ?>>Veteran</option>
                            <option value="Master" <?php if ($user['accType'] === 'Master') echo 'selected'; ?>>Master</option>
                            <option value="Experienced" <?php if ($user['accType'] === 'Experienced') echo 'selected'; ?>>Experienced</option>
                            <option value="Intermediate" <?php if ($user['accType'] === 'Intermediate') echo 'selected'; ?>>Intermediate</option>
                            <option value="Noob" <?php if ($user['accType'] === 'Noob') echo 'selected'; ?>>Noob</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="favorite_rock">Favorite Rock:</label>
                        <input type="text" id="favorite_rock" name="favRock" value="<?php echo $user['favRock']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" id="password" name="password" value="<?php echo $user['password']; ?>">
                        <input type="checkbox" onclick="myFunction()">Show Password
<script> function myFunction() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
                    </div>
                    <div class="form-group">
                        <button class="form__button" type="submit" name="save">Save</button>
                        <button class="form__button" type="submit" name="delete">Delete</button>
                    </div>
                    </div>
                </form>
            <?php else : ?>
                <!-- Display the profile information -->
                <div class="profile">
                    <br>
                    <h1>User Information</h1>
                    <p><strong>Name:</strong> <?php echo $user['name']; ?></p>
                    <p><strong>Email:</strong> <?php echo $user['email']; ?></p>
                    <p><strong>Date of Birth:</strong> <?php echo $user['birth_date']; ?></p>
                    <p><strong>Age:</strong> <?php echo $user['age']; ?></p>
                    <p><strong>Account Type:</strong> <?php echo $user['accType']; ?></p>
                    <p><strong>Favorite Rock:</strong> <?php echo $user['favRock']; ?></p>
                </div>
                <!-- Add the edit button to allow users to edit their profile -->
                <form action="" method="post">
                    <button type="submit" name="edit" id="edit">Edit Profile</button>
                </form>
            <?php endif; ?>
        </div>
        
    </main>
    <script src="index.js">
        function toggleTheme() {
            var themeStyle = document.getElementById("theme-style");
            if (themeStyle.getAttribute("href") === "dark.css") {
                themeStyle.href = "light.css";
            } else {
                themeStyle.href = "dark.css";
            }
        }
    </script>
</body>
</html>
