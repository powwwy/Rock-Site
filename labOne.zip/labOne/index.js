 // Get the header element
 var header = document.querySelector("header");

 // Get the offset position of the header
 var sticky = header.offsetTop;

 // Function to add the "sticky" class to the header when scrolling
 function makeHeaderSticky() {
   if (window.scrollY > sticky) {
     header.classList.add("sticky");
   } else {
     header.classList.remove("sticky");
   }
 }

 // trigger the sticky header
 window.addEventListener("scroll", makeHeaderSticky);

// Check if the user's preference is set to dark mode
const prefersDarkMode = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;

// Get the theme toggle button and current theme style
const themeToggle = document.getElementById('theme-toggle');

// Function to toggle the theme
function toggleTheme() {
  const themeStyle = document.getElementById('theme-style');
  const currentTheme = themeStyle.getAttribute('href');
  const newTheme = currentTheme === 'styles.css' ? 'dark.css' : 'styles.css';
  themeStyle.setAttribute('href', newTheme);

  // Store the selected theme in local storage
  localStorage.setItem('theme', newTheme);
}

// Set the initial theme based on the stored value
const storedTheme = localStorage.getItem('theme');
const themeStyle = document.getElementById('theme-style');
themeStyle.setAttribute('href', storedTheme || 'styles.css');

