<?php
// Connect to the DB server
$server = 'localhost';
$user = 'root';
$password = '';
$database = 'user_details';

$conn = mysqli_connect($server, $user, $password, $database);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
else{
    echo "";
}


// Uncomment the code below if you want to create the database once.
/*
$sql = "CREATE DATABASE IF NOT EXISTS nothing";
if (mysqli_query($connect, $sql)) {
    echo "\nDB created successfully";
} else {
    echo "Error creating database: " . mysqli_error($connect);
}
*/

// Close the connection
//mysqli_close($connect);
?>
